java -cp /data/xce/banzi/search-kafka/target/search-kafka-1.0-SNAPSHOT.jar:/data/xce/banzi/search-kafka/lib/*:/data/xce/banzi/search-kafka/ com.renren.kafka.tester.ProducerTester
